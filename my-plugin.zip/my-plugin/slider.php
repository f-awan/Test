<?php
function my_plugin_slider() {
    return '<div class="my-plugin-slider">This is the slider view.</div>';
}
?>
