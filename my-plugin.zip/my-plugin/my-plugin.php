<?php
/*
Plugin Name: My Plugin
Plugin URI: https://thewebcrafters.pk
Description: A brief description of what the plugin does.
Version: 1.0
Author: Your Faraz Awan
Author URI: https://thewebcrafters.pk
License: GPL2
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

function plugin_activation() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'emp';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name tinytext NOT NULL,
        email text NOT NULL,
        status tinyint(1) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    $wpdb->insert(
        $table_name,
        array(
            'id' => 1,
            'name' => 'faraz',
            'email' => 'faraz.awan2012@hotmail.com',
            'status' => 1
        )
    );
}
register_activation_hook(__FILE__, 'plugin_activation');

// Deactivation hook
function plugin_deactivation() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'emp';
    $wpdb->query("TRUNCATE TABLE $table_name");
}
register_deactivation_hook(__FILE__, 'plugin_deactivation');

include_once plugin_dir_path(__FILE__) . 'gallery.php';
include_once plugin_dir_path(__FILE__) . 'slider.php';

function my_plugin_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'type' => 'gallery',
        ),
        $atts,
        'my-plugin'
    );
    if ($atts['type'] === 'slider') {
        return my_plugin_slider();
    } else {
        return my_plugin_gallery();
    }
}
add_shortcode('my-plugin', 'my_plugin_shortcode');

function load_assets() {
    wp_enqueue_style('my-plugin-front-css', plugin_dir_url(__FILE__) . 'assets/front/css/style.css');
    wp_enqueue_script('my-plugin-front-js', plugin_dir_url(__FILE__) . 'assets/front/js/main.js', array('jquery'), null, true);
    wp_add_inline_script('my-plugin-front-js', 'var ajaxUrl = "'.admin_url('admin-ajax.php').'";', 'before');
}
add_action('wp_enqueue_scripts', 'load_assets');

function load_admin_assets() {
    wp_enqueue_style('my-plugin-admin-css', plugin_dir_url(__FILE__) . 'assets/admin/css/admin-style.css');
    wp_enqueue_script('my-plugin-admin-js', plugin_dir_url(__FILE__) . 'assets/front/js/main.js', array('jquery'), null, true);
    wp_add_inline_script('my-plugin-admin-js', 'var ajaxUrl = "'.admin_url('admin-ajax.php').'";', 'before');
}
add_action('admin_enqueue_scripts', 'load_admin_assets');

function display_data() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'emp'; // Use $wpdb->prefix instead of $table_prefix
    $results = $wpdb->get_results("SELECT * FROM `$table_name`");

    if (empty($results)) {
        return 'No data found.';
    }

  ob_start();
  ?>
  <table width="100%" border="1">
    <tr>
        <th>ID</th>
        <th>Email</th>
        <th>Name</th>
        <th>Status</th>
    </tr>
    <?php foreach($results as $row) { ?>
        <tr>
        <td><?php echo $row->id; ?></td>
        <td><?php echo $row->email; ?></td>
        <td><?php echo $row->name; ?></td>
        <td><?php echo $row->status; ?></td>
    </tr>
   <?php } ?> 
  </table>
<?php
$output = ob_get_clean();
    return $output;
}
add_shortcode('display_data_shortcode', 'display_data');

function display_posts(){
    $args = array(
        'post_type'=> 'post',
    );
    $query = new WP_Query($args);
    ob_start();
    if($query->have_posts()): 
     ?> <ul> <?php   
        while($query->have_posts()): $query->the_post();
?>
<li><?php echo get_the_title();?> --><br/> <?php the_content()?></li>
<?php
endwhile;
?></ul><?php
endif;
wp_reset_postdata();
$output = ob_get_clean();
    return $output;
}

add_shortcode('display_post_data', 'display_posts');

// Function to create the admin menu
function my_plugin_menu() {
    // Add a new top-level menu (main menu) in the admin dashboard
    add_menu_page(
        'My Plugin',            // Page title
        'My Plugin',            // Menu title
        'manage_options',       // Capability required to view this menu
        'my-plugin',            // Menu slug
        'my_plugin_page_func', 
        'dashicons-admin-generic',
        20 
    );
    add_submenu_page(
        'my-plugin',            // Parent slug
        'All Employees',    // Page title
        'All Employees',              // Sub-menu title
        'manage_options',       // Capability required to view this sub-menu
        'my-plugin',    // Sub-menu slug
        'my_plugin_page_func' // Callback function to display the content of the sub-menu
    );
    add_submenu_page(
        'my-plugin',            // Parent slug
        'My Plugin Subpage',    // Page title
        'Subpage',              // Sub-menu title
        'manage_options',       // Capability required to view this sub-menu
        'my-plugin-subpage',    // Sub-menu slug
        'my_plugin_subpage_func' // Callback function to display the content of the sub-menu
    );
}
add_action('admin_menu', 'my_plugin_menu');

function my_plugin_page_func() {

    echo '<div class="wrap">';
    echo '<h1>Welcome to My Plugin</h1>';
    echo '<p>This is the admin page for My Plugin.</p>';
    include 'admin/all-employees.php';
    echo '</div>';
}

function my_plugin_subpage_func() {
    echo '<div class="wrap">';
    echo '<h1>Welcome to My Plugin Subpage</h1>';
    echo '<p>This is the subpage of My Plugin.</p>';
    echo '</div>';
}

add_action('wp_ajax_my_search_func', 'my_search_func');
add_action('wp_ajax_nopriv_my_search_func', 'my_search_func');
function my_search_func(){
    global $wpdb;
    $table_name = $wpdb->prefix . 'emp';
    $search_term = sanitize_text_field($_POST['search_term']);
    if(!empty($search_term)) {
        $q = "SELECT * FROM `$table_name` WHERE `name` LIKE '%$search_term%'";
    } else {
        $q = "SELECT * FROM `$table_name`";
    }
    $results = $wpdb->get_results($q);
ob_start();
foreach($results as $row) {?>
    <tr>
        <td><?php echo $row->id; ?></td>
        <td><?php echo $row->email; ?></td>
        <td><?php echo $row->name; ?></td>
        <td><?php echo $row->status; ?></td>
    </tr>
 <?php }
echo ob_get_clean();
    wp_die();
}

//Display employee data on the front page by using shortcode
function all_emp_data() {
    ob_start();
    include plugin_dir_path(__FILE__) . 'front/all-employees.php';
    return ob_get_clean();
}
add_shortcode('display-employee', 'all_emp_data');

// Register Custom Post Type "Cars"
function my_plugin_create_post_type() {
    $labels = array(
        'name'               => _x( 'Cars', 'post type general name', 'textdomain' ),
        'singular_name'      => _x( 'Car', 'post type singular name', 'textdomain' ),
        'menu_name'          => _x( 'Cars', 'admin menu', 'textdomain' ),
        'name_admin_bar'     => _x( 'Car', 'add new on admin bar', 'textdomain' ),
        'add_new'            => _x( 'Add New', 'car', 'textdomain' ),
        'add_new_item'       => __( 'Add New Car', 'textdomain' ),
        'new_item'           => __( 'New Car', 'textdomain' ),
        'edit_item'          => __( 'Edit Car', 'textdomain' ),
        'view_item'          => __( 'View Car', 'textdomain' ),
        'all_items'          => __( 'All Cars', 'textdomain' ),
        'search_items'       => __( 'Search Cars', 'textdomain' ),
        'parent_item_colon'  => __( 'Parent Cars:', 'textdomain' ),
        'not_found'          => __( 'No cars found.', 'textdomain' ),
        'not_found_in_trash' => __( 'No cars found in Trash.', 'textdomain' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'car' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
    );

    register_post_type( 'car', $args );
}
add_action( 'init', 'my_plugin_create_post_type' );

// Register Custom Taxonomy "Car Types"
function my_plugin_create_taxonomy() {
    $labels = array(
        'name'              => _x( 'Car Types', 'taxonomy general name', 'textdomain' ),
        'singular_name'     => _x( 'Car Type', 'taxonomy singular name', 'textdomain' ),
        'search_items'      => __( 'Search Car Types', 'textdomain' ),
        'all_items'         => __( 'All Car Types', 'textdomain' ),
        'parent_item'       => __( 'Parent Car Type', 'textdomain' ),
        'parent_item_colon' => __( 'Parent Car Type:', 'textdomain' ),
        'edit_item'         => __( 'Edit Car Type', 'textdomain' ),
        'update_item'       => __( 'Update Car Type', 'textdomain' ),
        'add_new_item'      => __( 'Add New Car Type', 'textdomain' ),
        'new_item_name'     => __( 'New Car Type Name', 'textdomain' ),
        'menu_name'         => __( 'Car Types', 'textdomain' ),
    );

    $args = array(
        'hierarchical'      => true, // Set to 'false' for non-hierarchical taxonomy (like tags)
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'car-type' ),
    );

    register_taxonomy( 'car_type', array( 'car' ), $args );
}
add_action( 'init', 'my_plugin_create_taxonomy' );
