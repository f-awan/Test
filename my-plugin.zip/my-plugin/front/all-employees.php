<?php
global $wpdb;
$table_name = $wpdb->prefix . 'emp';
if(isset($_GET['my_search_term'])) {
    $search_term = sanitize_text_field($_GET['my_search_term']);
    $q = "SELECT * FROM `$table_name` WHERE `name` LIKE '%$search_term%'";
} else {
    $q = "SELECT * FROM `$table_name`";
}
$results = $wpdb->get_results($q);
if (empty($results)) {
    echo 'No data found.';
}
ob_start();
?>
<form action="<?php echo admin_url('admin.php') ?>" id="my-search-form">
    <input type="hidden" name="page" value="my-plugin-page">
    <input type="text" name="my_search_term" id="my-search-term">
    <input type="submit" value="search" name="search">
</form>
<div id="search-results" class="table-responsive">
    <table class="table">
        <thead>
        <tr>
            <th class="manage-column">ID</th>
            <th class="manage-column">Email</th>
            <th class="manage-column">Name</th>
            <th class="manage-column">Status</th>
        </tr>
        </thead>
        <tbody id="table-search-results">
        <?php foreach($results as $row) { ?>
            <tr>
                <td><?php echo $row->id; ?></td>
                <td><?php echo $row->email; ?></td>
                <td><?php echo $row->name; ?></td>
                <td><?php echo $row->status; ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<?php
$output = ob_get_clean();
echo $output;
?>
