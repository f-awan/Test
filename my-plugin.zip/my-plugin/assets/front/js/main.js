jQuery(document).ready(function($) {
    $("#my-search-form").submit(function(event) {
        event.preventDefault();
        var search_term = $("#my-search-term").val();
        let formData = new FormData();
        formData.append('action','my_search_func');
        formData.append('search_term',search_term);
        $.ajax({
            url: ajaxUrl,
            method: 'post',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                $("#table-search-results").html(response);
            },
            error: function() {
                console.log("error");
            }
        });
  });
});