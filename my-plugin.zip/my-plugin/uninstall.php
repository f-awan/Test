<?php

if (!defined('ABSPATH') || !defined('WP_UNINSTALL_PLUGIN')) {
    header('location: http://localhost/hoteling/');
    exit; // Exit if accessed directly or if WP_UNINSTALL_PLUGIN is not defined
}
global $wpdb;
$table_name = $wpdb->prefix . 'emp';
$wpdb->query("DROP TABLE IF EXISTS $table_name");

?>