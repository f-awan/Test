<?php
function my_plugin_gallery() {
    return '<div class="my-plugin-gallery">This is the gallery view.</div>';
}
?>
