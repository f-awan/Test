<?php
/*
Template Name: Listings Page
*/

get_header();
?>

<div class="container">
    <h1>Car Listings</h1>

    <?php
    $args = array(
        'post_type' => 'car',
        'posts_per_page' => 10,
    );

    $listings_query = new WP_Query($args);

    if ($listings_query->have_posts()) :
        while ($listings_query->have_posts()) : $listings_query->the_post();
    ?>
            <div class="listing">
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="listing-content">
                    <?php the_excerpt(); ?>
                </div>
            </div>
    <?php
        endwhile;
        wp_reset_postdata();
    else :
    ?>
        <p>No listings found</p>
    <?php endif; ?>
</div>

<?php
get_footer();
?>
