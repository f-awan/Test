<?php

function create_listings_post_type() {
    $labels = array(
        'name' => _x('Listings', 'Post Type General Name', 'text_domain'),
        'singular_name' => _x('Listing', 'Post Type Singular Name', 'text_domain'),
        'menu_name' => __('Listings', 'text_domain'),
        'name_admin_bar' => __('Listing', 'text_domain'),
        'archives' => __('Listing Archives', 'text_domain'),
        'attributes' => __('Listing Attributes', 'text_domain'),
        'parent_item_colon' => __('Parent Listing:', 'text_domain'),
        'all_items' => __('All Listings', 'text_domain'),
        'add_new_item' => __('Add New Listing', 'text_domain'),
        'add_new' => __('Add New', 'text_domain'),
        'new_item' => __('New Listing', 'text_domain'),
        'edit_item' => __('Edit Listing', 'text_domain'),
        'update_item' => __('Update Listing', 'text_domain'),
        'view_item' => __('View Listing', 'text_domain'),
        'view_items' => __('View Listings', 'text_domain'),
        'search_items' => __('Search Listing', 'text_domain'),
        'not_found' => __('Not found', 'text_domain'),
        'not_found_in_trash' => __('Not found in Trash', 'text_domain'),
        'featured_image' => __('Featured Image', 'text_domain'),
        'set_featured_image' => __('Set featured image', 'text_domain'),
        'remove_featured_image' => __('Remove featured image', 'text_domain'),
        'use_featured_image' => __('Use as featured image', 'text_domain'),
        'insert_into_item' => __('Insert into listing', 'text_domain'),
        'uploaded_to_this_item' => __('Uploaded to this listing', 'text_domain'),
        'items_list' => __('Listings list', 'text_domain'),
        'items_list_navigation' => __('Listings list navigation', 'text_domain'),
        'filter_items_list' => __('Filter listings list', 'text_domain'),
    );
    $args = array(
        'label' => __('Listing', 'text_domain'),
        'description' => __('Custom Post Type for Listings', 'text_domain'),
        'labels' => $labels,
        'supports' => array('title', 'editor', 'thumbnail', 'revisions'),
        'taxonomies' => array('category', 'post_tag'),
        'hierarchical' => false,
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'exclude_from_search' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type('listings', $args);
}
add_action('init', 'create_listings_post_type', 0);


function fetch_and_insert_posts() {
    // Verify nonce for security
    check_ajax_referer('fetch_posts_nonce', 'security');

    // Get the external API data
    $response = wp_remote_get('https://jsonplaceholder.typicode.com/posts');
    if (is_wp_error($response)) {
        wp_send_json_error('Failed to fetch external data');
        return;
    }

    $posts = json_decode(wp_remote_retrieve_body($response), true);
	var_dump($posts);
    if (empty($posts)) {
        wp_send_json_error('No data found');
        return;
    }

    foreach ($posts as $post_data) {
        // Prepare post data
        $post_args = array(
            'post_title'   => sanitize_text_field($post_data['title']),
            'post_content' => sanitize_textarea_field($post_data['body']),
            'post_status'  => 'publish',
            'post_author'  => 1, // Change to the desired author ID
            'post_type'    => 'post',
        );

        // Insert the post into the database
        wp_insert_post($post_args);
    }

    wp_send_json_success('Posts imported successfully');
}
add_action('wp_ajax_fetch_and_insert_posts', 'fetch_and_insert_posts');
add_action('wp_ajax_nopriv_fetch_and_insert_posts', 'fetch_and_insert_posts');

function enqueue_custom_script() {
    wp_enqueue_script('custom-fetch-posts', get_stylesheet_directory_uri() . '/js/custom-fetch-posts.js', array('jquery'), null, true);
    wp_localize_script('custom-fetch-posts', 'ajax_object', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('fetch_posts_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'enqueue_custom_script');



