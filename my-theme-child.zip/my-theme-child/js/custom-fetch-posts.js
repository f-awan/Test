jQuery(document).ready(function($) {
	alert('test');
    // Function to fetch data from external API and send to WordPress AJAX handler
    function fetchAndInsertPosts() {
        $.ajax({
            url: ajax_object.ajax_url,
            method: 'POST',
            data: {
                action: 'fetch_and_insert_posts',
                security: ajax_object.nonce
            },
            success: function(response) {
                if (response.success) {
                    console.log('Posts imported successfully:', response.data);
                } else {
                    console.error('Error importing posts:', response.data);
                }
            },
            error: function(error) {
                console.error('AJAX error:', error);
            }
        });
    }

    // Call the function to fetch and insert posts
    fetchAndInsertPosts();
});
