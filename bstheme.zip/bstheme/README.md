# Basic WordPress Theme Development Tutorial

Learn how to build a WordPress theme development series

## Getting Started
* [Video Series on YouTube]
(https://www.youtube.com/playlist?list=PLgFB6lmeXFOpHnNmQ4fdIYA5X_9XhjJ9d)
