<div class="col-xl-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <article>
                        <div class="post-img">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('full', ['class' => 'img-fluid']); ?>
                            <?php else : ?>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/blog/blog-1.jpg" alt="" class="img-fluid">
                            <?php endif; ?>
                        </div>
                        
                        <p class="post-category">
                            <?php
                            $category = get_the_category();
                            echo esc_html($category[0]->name);
                            ?>
                        </p>

                        <h2 class="title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>

                        <div class="d-flex align-items-center">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/img/blog/blog-author.jpg" alt="" class="img-fluid post-author-img flex-shrink-0">
                            <div class="post-meta">
                                <p class="post-author"><?php the_author(); ?></p>
                                <p class="post-date">
                                    <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date(); ?></time>
                                </p>
                            </div>
                        </div>
                    </article>
</div>