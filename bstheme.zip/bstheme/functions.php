<?php


// Load Stylesheets
function load_css()
{


		wp_register_style('bootstrap', get_template_directory_uri() . '/assets/vendor/bootstrap/css/bootstrap.min.css', array(), false, 'all' );
		wp_enqueue_style('bootstrap');


		wp_register_style('bootstrap-icons.css', get_template_directory_uri() . '/assets/vendor/bootstrap-icons/bootstrap-icons.css', array(), false, 'all' );
		wp_enqueue_style('bootstrap-icons.css');


		wp_register_style('aos', get_template_directory_uri() . '/assets/vendor/aos/aos.css', array(), false, 'all' );
		wp_enqueue_style('aos');

		wp_register_style('glightbox-css', get_template_directory_uri() . '/assets/vendor/glightbox/css/glightbox.min.css', array(), false, 'all' );
		wp_enqueue_style('glightbox-css');

		wp_register_style('swiper-css', get_template_directory_uri() . '/assets/vendor/swiper/swiper-bundle.min.css', array(), false, 'all' );
		wp_enqueue_style('swiper-css');

		wp_register_style('main-css', get_template_directory_uri() . '/assets/css/main.css', array(), false, 'all' );
		wp_enqueue_style('main-css');


	
}
add_action('wp_enqueue_scripts','load_css');



// Load Javascript
function load_js()
{	
		wp_enqueue_script('jquery');

		wp_register_script('bootstrap', get_template_directory_uri() . '/assets/vendor/bootstrap/js/bootstrap.bundle.min.js', 'jquery', false, true);
		wp_enqueue_script('bootstrap');

		wp_register_script('php-mail', get_template_directory_uri() . '/assets/vendor/php-email-form/validate.js', 'jquery', false, true);
		wp_enqueue_script('php-mail');


		wp_register_script('aos-js', get_template_directory_uri() . '/assets/vendor/aos/aos.js', 'jquery', false, true);
		wp_enqueue_script('aos-js');

		wp_register_script('glightbox-js', get_template_directory_uri() . '/assets/vendor/glightbox/js/glightbox.min.js', 'jquery', false, true);
		wp_enqueue_script('glightbox-js');
		wp_register_script('purecounter-js', get_template_directory_uri() . '/assets/vendor/purecounter/purecounter_vanilla.js', 'jquery', false, true);
		wp_enqueue_script('purecounter-js');
		wp_register_script('lazyloaded-js', get_template_directory_uri() . '/assets/vendor/imagesloaded/imagesloaded.pkgd.min.js', 'jquery', false, true);
		wp_enqueue_script('lazyloaded-js');
		wp_register_script('isotope-js', get_template_directory_uri() . '/assets/vendor/isotope-layout/isotope.pkgd.min.js', 'jquery', false, true);
		wp_enqueue_script('isotope-js');
		wp_register_script('swiper-js', get_template_directory_uri() . '/assets/vendor/swiper/swiper-bundle.min.js', 'jquery', false, true);
		wp_enqueue_script('swiper-js');
		wp_register_script('custom', get_template_directory_uri() . '/assets/js/main.js', 'jquery', false, true);
		wp_enqueue_script('custom');

}
add_action('wp_enqueue_scripts', 'load_js');




// Theme Options
add_theme_support('menus');
add_theme_support('post-thumbnails');
add_theme_support('widgets');




// Menus
register_nav_menus(

		array(

			'top-menu' => 'Top Menu Location',
			'mobile-menu' => 'Mobile Menu Location',
			'footer-menu' => 'Footer Menu Location',

		)

);





// Custom Image Sizes
add_image_size('blog-large', 800, 600, false);
add_image_size('blog-small', 300, 200, true);




// Register Sidebars
function my_sidebars()
{


			register_sidebar(

						array(

								'name' => 'Page Sidebar',
								'id' => 'page-sidebar',
								'before_title' => '<h3 class="widget-title">',
								'after_title' => '</h3>'

						)

			);


			register_sidebar(

						array(

								'name' => 'Blog Sidebar',
								'id' => 'blog-sidebar',
								'before_title' => '<h3 class="widget-title">',
								'after_title' => '</h3>'

						)

			);



}
add_action('widgets_init','my_sidebars');

function tft_register_footer_widgets() {
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area 1', 'textdomain' ),
        'id'            => 'footer-1',
        'description'   => __( 'Add widgets here to appear in your footer.', 'textdomain' ),
        'before_widget' => '<div id="%1$s" class="tft-footer-section widget_block %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => 'h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Widget Area 2', 'textdomain' ),
        'id'            => 'footer-2',
        'description'   => __( 'Add widgets here to appear in your footer.', 'textdomain' ),
        'before_widget' => '<div id="%1$s" class="tft-footer-section widget_block %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Widget Area 3', 'textdomain' ),
        'id'            => 'footer-3',
        'description'   => __( 'Add widgets here to appear in your footer.', 'textdomain' ),
        'before_widget' => '<div id="%1$s" class="tft-footer-section widget_block %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Widget Area 4', 'textdomain' ),
        'id'            => 'footer-4',
        'description'   => __( 'Add widgets here to appear in your footer.', 'textdomain' ),
        'before_widget' => '<div id="%1$s" class="tft-footer-section widget_block %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
}
add_action( 'widgets_init', 'tft_register_footer_widgets' );


/*Add Custom Contact Info Widget in Widget Page*/
class Contact_Info_Widget extends WP_Widget {

    function __construct() {
        parent::__construct(
            'contact_info_widget', 
            __('Contact Info', 'textdomain'),
            array( 'description' => __( 'A Widget to display contact information', 'textdomain' ), )
        );
    }

    public function widget( $args, $instance ) {
        $address = ! empty( $instance['address'] ) ? $instance['address'] : '';
        $phone = ! empty( $instance['phone'] ) ? $instance['phone'] : '';
        $email = ! empty( $instance['email'] ) ? $instance['email'] : '';

        echo $args['before_widget'];
		echo $args['before_title'] . __('Contact Info', 'textdomain') . $args['after_title'];
        if ( ! empty( $address ) ) {
            // echo $args['before_title'] . __('Address', 'textdomain') . $args['after_title'];
            echo '<p><strong>'. __('Address', 'textdomain') .'</strong>: ' . $address . '</p>';
        }
        if ( ! empty( $phone ) ) {
            //echo $args['before_title'] . __('Phone', 'textdomain') . $args['after_title'];
            echo '<p><strong>'. __('Phone', 'textdomain') .'</strong>: ' . $phone . '</p>';
        }
        if ( ! empty( $email ) ) {
            //echo $args['before_title'] . __('Email', 'textdomain') . $args['after_title'];
            echo '<p><strong>'. __('Email', 'textdomain') .'</strong>: ' . $email . '</p>';
        }
        echo $args['after_widget'];
    }

    public function form( $instance ) {
        $address = ! empty( $instance['address'] ) ? $instance['address'] : '';
        $phone = ! empty( $instance['phone'] ) ? $instance['phone'] : '';
        $email = ! empty( $instance['email'] ) ? $instance['email'] : '';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'address' ); ?>"><?php _e( 'Address:' ); ?></label> 
            <input class="widefat" id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>" type="text" value="<?php echo esc_attr( $address ); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'phone' ); ?>"><?php _e( 'Phone:' ); ?></label> 
            <input class="widefat" id="<?php echo $this->get_field_id( 'phone' ); ?>" name="<?php echo $this->get_field_name( 'phone' ); ?>" type="text" value="<?php echo esc_attr( $phone ); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'email' ); ?>"><?php _e( 'Email:' ); ?></label> 
            <input class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" type="text" value="<?php echo esc_attr( $email ); ?>">
        </p>
        <?php 
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['address'] = ( ! empty( $new_instance['address'] ) ) ? strip_tags( $new_instance['address'] ) : '';
        $instance['phone'] = ( ! empty( $new_instance['phone'] ) ) ? strip_tags( $new_instance['phone'] ) : '';
        $instance['email'] = ( ! empty( $new_instance['email'] ) ) ? strip_tags( $new_instance['email'] ) : '';

        return $instance;
    }
}

function register_contact_info_widget() {
    register_widget( 'Contact_Info_Widget' );
}
add_action( 'widgets_init', 'register_contact_info_widget' );


/*Add Custom Text box in Theme Customizer*/
function tft_customize_register( $wp_customize ) {
    // Add a new section for the copyright text
    $wp_customize->add_section( 'tft_footer_section', array(
        'title'       => __( 'Footer Settings', 'textdomain' ),
        'priority'    => 30,
        'description' => __( 'Add your copyright information here', 'textdomain' ),
    ) );

    // Add the setting for the copyright text
    $wp_customize->add_setting( 'tft_copyright_text', array(
        'default'           => __( '© 2024 Your Company Name. All rights reserved.', 'textdomain' ),
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    // Add the control for the copyright text
    $wp_customize->add_control( 'tft_copyright_text_control', array(
        'label'    => __( 'Copyright Text', 'textdomain' ),
        'section'  => 'tft_footer_section',
        'settings' => 'tft_copyright_text',
        'type'     => 'text',
    ) );
}
add_action( 'customize_register', 'tft_customize_register' );





function my_first_post_type()
{

	$args = array(


		'labels' => array(

					'name' => 'Cars',
					'singular_name' => 'Car',
		),
		'hierarchical' => true,
		'public' => true,
		'has_archive' => true,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array('title', 'editor', 'thumbnail','custom-fields'),
		//'rewrite' => array('slug' => 'cars'),	

	);


	register_post_type('cars', $args);


}
add_action('init', 'my_first_post_type');








function my_first_taxonomy()
{

			$args = array(

					'labels' => array(
							'name' => 'Brands',
							'singular_name' => 'Brand',
					),

					'public' => true,
					'hierarchical' => true,

			);


			register_taxonomy('brands', array('cars'), $args);

}
add_action('init', 'my_first_taxonomy');







add_action('wp_ajax_enquiry', 'enquiry_form');
add_action('wp_ajax_nopriv_enquiry', 'enquiry_form');
function enquiry_form()
{


	if(  !wp_verify_nonce( $_POST['nonce'], 'ajax-nonce' )  )
	{

		wp_send_json_error('Nonce is incorrect', 401);
		die();

	}



	$formdata = [];

	wp_parse_str($_POST['enquiry'], $formdata);


	// Admin email
	$admin_email = get_option('admin_email');


	// Email headers
	$headers[] = 'Content-Type: text/html; charset=UTF-8';
	$headers[] = 'From: My Website <' . $admin_email . '>';
	$headers[] = 'Reply-to:' . $formdata['email'];

	// Who are we sending the email to?
	$send_to = $admin_email;

	// Subject
	$subject = "Enquiry from " . $formdata['fname'] . ' ' . $formdata['lname']; 

	// Message
	$message = '';

	foreach($formdata as $index => $field)
	{
		$message .= '<strong>' . $index . '</strong>: ' . $field . '<br />';
	}


	try {

		if( wp_mail($send_to, $subject, $message, $headers) )
		{

			wp_send_json_success('Email sent');

		}
		else {


			wp_send_json_error('Email error');

		}

	} catch (Exception $e)
	{
			wp_send_json_error($e->getMessage());
	}


	wp_send_json_success( $formdata['fname'] );
}





/**
 * Register Custom Navigation Walker
 */
function register_navwalker(){
	require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';
}
add_action( 'after_setup_theme', 'register_navwalker' );





add_action('phpmailer_init','custom_mailer');
function custom_mailer( PHPMailer $phpmailer )
{

	$phpmailer->SetFrom('sean@mrdigital.com.au', 'Sean Freitas');
	$phpmailer->Host = 'email-smtp.us-west-2.amazonaws.com';
	$phpmailer->Port = 587;
	$phpmailer->SMTPAuth = true;
	$phpmailer->SMTPSecure = 'tls';
	$phpmailer->Username = SMTP_LOGIN;
	$phpmailer->Password = SMTP_PASSWORD;
	$phpmailer->IsSMTP();

}



function my_shortcode($atts, $content = null, $tag = '')
{

	ob_start();

	print_r($content);

	set_query_var('attributes', $atts);

	get_template_part('includes/latest', 'cars');

	return ob_get_clean();

}
add_shortcode('latest_cars', 'my_shortcode');



function my_phone()
{
	return '<a href="tel:0400 200 222">0400 200 222</a>';
}
add_shortcode('phone', 'my_phone');







function search_query()
{

	$paged = ( get_query_var('paged')  )  ? get_query_var('paged') : 1; 


	$args = [

		'paged' => $paged,
		'post_type' => 'cars',
		'posts_per_page' => 1,
		'tax_query' => [],
		'meta_query' => [
				'relation' => 'AND',
		 ],

	];

	if( isset($_GET['keyword']) )
	{

			if(!empty($_GET['keyword']))
			{
					$args['s'] = sanitize_text_field( $_GET['keyword'] );
			}

	}



	if( isset($_GET['brand']) )
	{
		if(!empty($_GET['brand']))
		{
			$args['tax_query'][] = [

					'taxonomy' => 'brands',
					'field' => 'slug',
					'terms' => array( sanitize_text_field( $_GET['brand'] ) )

			];
		}
	}


	if( isset($_GET['price_above']) )
	{
		if(!empty($_GET['price_above']))
		{
				$args['meta_query'][] = array(

						'key' => 'price',
						'value' => sanitize_text_field( $_GET['price_above']) ,
						'type' => 'numeric',
						'compare' => '>='
				);
		}
	}




	if( isset($_GET['price_below']) )
	{
		if(!empty($_GET['price_below']))
		{
		  

			$args['meta_query'][] = array(

				'key' => 'price',
				'value' => sanitize_text_field( $_GET['price_below']) ,
				'type' => 'numeric',
				'compare' => '<='
		);

		}
	}


	return  new WP_Query($args);



}


/* Custom Testimonials Post */
function create_testimonials_cpt() {
    $labels = array(
        'name' => __('Testimonials'),
        'singular_name' => __('Testimonial'),
        'menu_name' => __('Testimonials'),
        'name_admin_bar' => __('Testimonial'),
        'add_new' => __('Add New'),
        'add_new_item' => __('Add New Testimonial'),
        'new_item' => __('New Testimonial'),
        'edit_item' => __('Edit Testimonial'),
        'view_item' => __('View Testimonial'),
        'all_items' => __('All Testimonials'),
        'search_items' => __('Search Testimonials'),
        'not_found' => __('No testimonials found.'),
        'not_found_in_trash' => __('No testimonials found in Trash.'),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'testimonials'),
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true,
    );

    register_post_type('testimonials', $args);
}
add_action('init', 'create_testimonials_cpt');



/** Custom Meta Boxes for Testimonials */
function add_testimonials_metaboxes() {
    add_meta_box(
        'testimonial_details',
        'Testimonial Details',
        'render_testimonial_metabox',
        'testimonials',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'add_testimonials_metaboxes');
function render_testimonial_metabox($post) {
    // Add nonce for security and authentication
    wp_nonce_field('testimonial_nonce_action', 'testimonial_nonce');

    // Retrieve existing values from the database
    $name = get_post_meta($post->ID, '_testimonial_name', true);
    $designation = get_post_meta($post->ID, '_testimonial_designation', true);
    $description = get_post_meta($post->ID, '_testimonial_description', true);

    // Output fields
    echo '<label for="testimonial_name">Name:</label>';
    echo '<input type="text" id="testimonial_name" name="testimonial_name" value="' . esc_attr($name) . '" class="widefat"><br><br>';

    echo '<label for="testimonial_designation">Designation:</label>';
    echo '<input type="text" id="testimonial_designation" name="testimonial_designation" value="' . esc_attr($designation) . '" class="widefat"><br><br>';

    echo '<label for="testimonial_description">Description:</label>';
    echo '<textarea id="testimonial_description" name="testimonial_description" class="widefat" rows="5">' . esc_textarea($description) . '</textarea>';
}

/** Save Meta Box Data of Testimonials */
function save_testimonial_metabox_data($post_id) {
    // Check if nonce is set
    if (!isset($_POST['testimonial_nonce'])) {
        return;
    }
    // Verify that the nonce is valid
    if (!wp_verify_nonce($_POST['testimonial_nonce'], 'testimonial_nonce_action')) {
        return;
    }
    // Check if the user has permissions to save data
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    // Check if not an autosave
    if (wp_is_post_autosave($post_id)) {
        return;
    }
    // Check if not a revision
    if (wp_is_post_revision($post_id)) {
        return;
    }
    // Sanitize and save fields
    if (isset($_POST['testimonial_name'])) {
        update_post_meta($post_id, '_testimonial_name', sanitize_text_field($_POST['testimonial_name']));
    }
    if (isset($_POST['testimonial_designation'])) {
        update_post_meta($post_id, '_testimonial_designation', sanitize_text_field($_POST['testimonial_designation']));
    }
    if (isset($_POST['testimonial_description'])) {
        update_post_meta($post_id, '_testimonial_description', sanitize_textarea_field($_POST['testimonial_description']));
    }
}
add_action('save_post', 'save_testimonial_metabox_data');










