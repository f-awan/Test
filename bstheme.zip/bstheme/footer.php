<footer id="footer" class="footer position-relative">
    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-5 col-md-12 footer-about">
		<?php dynamic_sidebar( 'footer-1' ); ?>
        </div>

        <div class="col-lg-2 col-6 footer-links">
		<?php dynamic_sidebar( 'footer-2' ); ?>
        </div>

        <div class="col-lg-2 col-6 footer-links">
		<?php dynamic_sidebar( 'footer-3' ); ?>
        </div>

        <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
		<?php dynamic_sidebar( 'footer-4' ); ?>
        </div>

      </div>
    </div>

    <div class="container copyright text-center mt-4">
      <p><?php echo esc_html( get_theme_mod( 'tft_copyright_text', __( '© 2024 Your Company Name. All rights reserved.', 'textdomain' ) ) ); ?></p>
      <div class="credits">
        Designed by <a href="https://thewebcrafters.pk">The Web Crafters</a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <!-- <div id="preloader"></div> -->

</body>

</html>




<?php wp_footer();?>
</body>
</html>